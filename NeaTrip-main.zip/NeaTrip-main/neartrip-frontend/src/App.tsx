import HomeFeed from './pages/HomeFeed';

function App() {
  return <HomeFeed />;
}

export default App;